# Flask Web Application

## Installation
1. Installera Python 3.9 eller senare.
2. Installera Flask: `pip install flask`.
3. Kör applikationen med kommandot: `python app.py`.

## Öppna sidan
När servern startar, öppna `http://127.0.0.1:9000` i din webbläsare.
