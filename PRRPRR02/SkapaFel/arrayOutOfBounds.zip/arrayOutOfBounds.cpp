#include <iostream>
#include <vector>

using namespace std;

int main(){
    string cars[4] = {"Volvo", "BMW", "Ford", "Mazda"};

    cout << cars[0] << endl;
    // Felet. Index 5 finns inte med i listan
    cout << cars[5] << endl;
}